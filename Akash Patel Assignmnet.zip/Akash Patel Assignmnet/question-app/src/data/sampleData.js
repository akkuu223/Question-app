const sampleData = {
  "response_code" : 0,
  "results" : [
    {
      "category": "Geography",
      "type": "multiple",
      "difficulty": "hard",
      "question": "In which city, is the Big Nickel located in Canada?",
      "correct_answer": "Sudbury, Ontario",
      "incorrect_answers": [
        "Calgary, Alberta",
        "Halifax, Nova Scotia ",
        "Victoria, British Columbia"
      ]
    },
    {
      "category": "Entertainment: Film",
      "type": "multiple",
      "difficulty": "medium",
      "question": "Which of the following James Bond villains is not affiliated with the SPECTRE organization?",
      "correct_answer": "Auric Goldfinger",
      "incorrect_answers": [
        "Dr. Julius No",
        "Rosa Klebb",
        "Emilio Largo"
      ]
    },
    {
      "category": "Science: Computers",
      "type": "boolean",
      "difficulty": "easy",
      "question": "Linus Torvalds created Linux and Git.",
      "correct_answer": "True",
      "incorrect_answers": [
        "False"
      ]
    },
    {
      "category": "Science & Nature",
      "type": "multiple",
      "difficulty": "hard",
      "question": "What is the scientific name of the knee cap?",
      "correct_answer": "Patella",
      "incorrect_answers": [
        "Femur",
        "Foramen Magnum",
        "Scapula"
      ]
    },
    {
      "category": "Entertainment: Cartoon & Animations",
      "type": "multiple",
      "difficulty": "medium",
      "question": "What year was the Disney film &quot;A Goofy Movie&quot; released?",
      "correct_answer": "1995",
      "incorrect_answers": [
        "1999",
        "2001",
        "1997"
      ]
    },
    {
      "category": "Entertainment: Music",
      "type": "multiple",
      "difficulty": "easy",
      "question": "What was the subject of the 2014 song &quot;CoCo&quot; by American rapper O. T. Genasis?",
      "correct_answer": "Cocaine",
      "incorrect_answers": [
        "Conan O&#039;Brien",
        "Cobalt(II) carbonate",
        "Coconut cream pie"
      ]
    },
    {
      "category": "History",
      "type": "multiple",
      "difficulty": "hard",
      "question": "The Second Boer War in 1899 was fought where?",
      "correct_answer": "South Africa",
      "incorrect_answers": [
        "Argentina",
        "Nepal",
        "Bulgaria"
      ]
    },
    {
      "category": "Entertainment: Video Games",
      "type": "multiple",
      "difficulty": "easy",
      "question": "What ingredients are required to make a cake in Minecraft?",
      "correct_answer": "Milk, Sugar, Egg, and Wheat",
      "incorrect_answers": [
        "Milk, Bread, Egg, and Wheat",
        "Milk, Sugar Cane, Egg, and Wheat",
        "Milk, Sugar, and Wheat"
      ]
    },
    {
      "category": "General Knowledge",
      "type": "boolean",
      "difficulty": "easy",
      "question": "One of Donald Trump&#039;s 2016 Presidential Campaign promises was to build a border wall between the United States and Mexico.",
      "correct_answer": "True",
      "incorrect_answers": [
        "False"
      ]
    },
    {
      "category": "Entertainment: Video Games",
      "type": "multiple",
      "difficulty": "easy",
      "question": "The name of the Metroid series comes from what?",
      "correct_answer": "An enemy in the game",
      "incorrect_answers": [
        "The final boss&#039;s name",
        "The main character&#039;s name",
        "A spaceship&#039;s name"
      ]
    },
    {
      "category": "Entertainment: Japanese Anime & Manga",
      "type": "multiple",
      "difficulty": "hard",
      "question": "Medaka Kurokami from &quot;Medaka Box&quot; has what abnormality?",
      "correct_answer": "The End",
      "incorrect_answers": [
        "Perfection",
        "Sandbox",
        "Fairness"
      ]
    },
    {
      "category": "Entertainment: Video Games",
      "type": "multiple",
      "difficulty": "medium",
      "question": "What was the main currency in Club Penguin?",
      "correct_answer": "Coins",
      "incorrect_answers": [
        "Stamps",
        "Tickets",
        "Gems"
      ]
    },
    {
      "category": "Entertainment: Video Games",
      "type": "boolean",
      "difficulty": "medium",
      "question": "The character that would eventually become Dr. Eggman was considered for the role of Sega&#039;s new flagship mascot before Sonic was.",
      "correct_answer": "True",
      "incorrect_answers": [
        "False"
      ]
    },
    {
      "category": "Geography",
      "type": "multiple",
      "difficulty": "medium",
      "question": "What is the capital of Lithuania?",
      "correct_answer": "Vilnius",
      "incorrect_answers": [
        "Tallinn",
        "Helsinki",
        "Riga"
      ]
    },
    {
      "category": "General Knowledge",
      "type": "multiple",
      "difficulty": "easy",
      "question": "The Canadian $1 coin is colloquially known as a what?",
      "correct_answer": "Loonie",
      "incorrect_answers": [
        "Boolie",
        "Foolie",
        "Moodie"
      ]
    }
  ]
}
export default sampleData;