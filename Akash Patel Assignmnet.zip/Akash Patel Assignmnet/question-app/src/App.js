import React, { useEffect, useState } from 'react';
import { BrowserRouter as Router, Route, Routes } from 'react-router-dom';
import QuestionList from './components/QuestionList';
import ReportPage from './components/ReportPage';
import HomePage from './components/HomePage';
import sampleData from './data/sampleData';
import './App.css';

function App() {
  const [responseData , setResponseData] =useState(null);

  const fetchData =async()=>{
    // let sampleData = await fetch('https://opentdb.com/api.php?amount=15')
    // sampleData = await sampleData.json();
    // console.log(sampleData)
    setResponseData(sampleData);
  }
  useEffect(()=>{
   fetchData();
  },[])
  
  let [selectedOptions, setSelectedOptions] = useState([]);
  const notifyParent =(e)=>{
    if(e===null){
      setSelectedOptions([]);
    }
    else
    {
      selectedOptions = selectedOptions.filter((x)=> x.question !== e.question);
      selectedOptions.push(e)
      setSelectedOptions(selectedOptions);
      
    }
  }
  return (
    <Router>
    {responseData !== null && 
      <div className="App">
        <Routes>
          <Route path='/' element={<HomePage/>}/>
        <Route path="/questionList" element ={
    <QuestionList
      questions={responseData.results}
      selectedOptions={notifyParent}
      // onOptionSelect={handleOptionSelect}
    />
  }
  />
  <Route path="/reports"
  element={  <ReportPage questions={responseData.results} selectedOptions={selectedOptions} />}
  />
        </Routes>
      </div>
    }
    </Router>
  );
}

export default App;
