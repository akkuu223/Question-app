// src/components/OverviewPanel.js

import React from "react";

function OverviewPanel({ questions, goToQuestion ,attendedQuestion }) {
  return (
    <>
    <div className="overview-panel">
      <ul className="ulStyle">
        {questions.map((question, index) => (
            <li style={ {marginRight:10}} key={index}>
            <button className={attendedQuestion.includes(index)?'btnGreen':''} onClick={() => goToQuestion(index + 1)}>Q{index + 1}</button>
          </li>
        ))}
      </ul>
    </div>
              </>
  );
}

export default OverviewPanel;
