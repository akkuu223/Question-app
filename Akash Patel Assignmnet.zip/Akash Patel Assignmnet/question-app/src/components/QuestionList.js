import React, { useEffect ,useState } from 'react';
import { Link,useNavigate } from 'react-router-dom';
import Question from './Questions';
import OverviewPanel from './OverviewPanel';


const QuestionList = ({ questions,selectedOptions }) => {
  const navigate =useNavigate();
  const [timer, setTimer] = useState(30 * 60); 
  let [attendedQuestion ,setAttendedQuestion] =useState([]);

  useEffect(() => {
    const intervalId = setInterval(() => {
      setTimer((prevTimer) => prevTimer - 1);
    }, 1000);

    return () => {
      clearInterval(intervalId);
    };
  }, []);

const notifyParent =(e,index)=>{
  attendedQuestion.push(index);
  setAttendedQuestion(attendedQuestion)
  selectedOptions(e)
}
useEffect(()=>{
selectedOptions(null);
},[])

useEffect(() => {
  if (timer === 0) {
    navigate('/reports')
  }
}, [timer]);

const [currentQuestion, setCurrentQuestion] = useState(0);
function handleGoToQuestion(e){
  setCurrentQuestion(e - 1);
}

  return (
    <div className="question-list">
      <OverviewPanel
        questions={questions}
        attendedQuestion ={attendedQuestion}
        goToQuestion={(e)=>handleGoToQuestion(e)}
      />
     <div className="timer-container">
        <div className="timer">Timer: {formatTime(timer)}</div>
      </div>
      {questions.map((questionData, index) => (
        <Question
        index ={index+1}
          key={index}
          questionData={questionData}
          selectedAnswer={(e)=>notifyParent(e,index)}
          currentQuestion ={currentQuestion}
        />
      ))}
        <Link to="/reports">
<button className="submit-button">Submit</button>
 </Link>
    </div>
  );
};
function formatTime(seconds) {
  const minutes = Math.floor(seconds / 60);
  const remainingSeconds = seconds % 60;
  return `${minutes}:${remainingSeconds < 10 ? '0' : ''}${remainingSeconds}`;
}

export default QuestionList;
