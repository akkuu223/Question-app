import React, { useState } from 'react';
import { useNavigate} from 'react-router-dom';

const HomePage = () => {
  const [value ,setValue] =useState('');
const navigate =useNavigate();

function validateEmail(email) {
  var regex = /^\w+([.-]?\w+)*@\w+([.-]?\w+)*(\.\w{2,3})+$/;
  return regex.test(email);
}
  const OnSubmit =()=>{
    if(value.length===0){
      alert("Please enter Email...")
    }
    else if(!validateEmail(value)){
      alert("Please enter Valid Email...")
    }
    else{
      navigate('/QuestionList');
    }
  }
  return (
    <div className="question">
      <h3>Please enter your email</h3>
   <input type='email'value={value} onChange={(e)=>setValue(e.target.value)} />
   <br></br>
   <br></br>
<button className="submit-button" onClick={OnSubmit}>Submit</button>

    </div>
  );
};

export default HomePage;
