import React from 'react';

const ReportPage = ({ questions, selectedOptions }) => {
const getAnswer =(record)=>{
const data = selectedOptions.filter((x)=>x.question===record.question);
if(data.length ===0)
return 'Not Answered';
else
return data[0].answer;
}

  return (
    <div className="report-page">
      <h2>Reports</h2>
      {questions.map((questionData, index) => (
        <div key={index} className="report-item">
          <p>{questionData.question}</p>
          <p>Your Answer: {getAnswer(questionData)} {getAnswer(questionData)===questionData.correct_answer?'✅':'❌'} </p>
          <p>Correct Answer: {questionData.correct_answer}</p>
        </div>
      ))}
    </div>
  );
};

export default ReportPage;
