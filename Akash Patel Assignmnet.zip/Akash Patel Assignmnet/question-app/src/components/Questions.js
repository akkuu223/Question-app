import React, { useState, useEffect } from 'react';

const Question = ({ questionData ,selectedAnswer,index ,currentQuestion}) => {
  const [selectedOption, setSelectedOption] = useState(null);

  const handleOptionClick = (index,option) => {
    setSelectedOption(index);
    selectedAnswer({question:questionData.question , answer :option})
  };


  useEffect(() => {
    if (index === currentQuestion) {
      const questionElement = document.getElementById(`question-${index}`);
      if (questionElement) {
        questionElement.scrollIntoView({ behavior: "smooth" });
      }
    }
  }, [index, currentQuestion]);

  return (
    <div className="question" id={`question-${index}`}>
      <p className="question-text">{index}.  {questionData.question}</p>
      <ul className="options-list">
        {questionData.incorrect_answers.map((option, index) => (
          <div key={index}>
          <li
            key={index}
            className={`option ${selectedOption === index ? 'selected' : ''}`}
            onClick={() => handleOptionClick(index,option)}
            >
            {option}
          </li>
            </div>
        ))}
         <li key={4} className={`option ${selectedOption === 4 ? 'selected' : ''}`} onClick={() => handleOptionClick(4,questionData.correct_answer)} >{questionData.correct_answer}</li>
      </ul>
    </div>
  );
};

export default Question;
